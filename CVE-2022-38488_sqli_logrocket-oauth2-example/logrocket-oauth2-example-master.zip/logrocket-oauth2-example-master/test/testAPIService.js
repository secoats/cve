module.exports = {
	helloWorld: helloWorld,
};

function helloWorld(req, res) {
	res.send("Hello World OAuth2!");
}
